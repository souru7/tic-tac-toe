$(document).ready(function(){
  var flag = true;
  var click = 0;
  var flag1 = 0;
  var flag2=0;
  var score1 =0;
  var score2=0;
  if(flag)
    $(".one").slideDown();
  $("li").on("click",function(){
    if(flag){
      if(($(this).text()=="")){
    $(this).text("O");
        click++;
        $(".one").slideUp();
        $(".two").slideDown();
      flag = 0;
      }
    }
    else{
      if($(this).text()==""){
      $(this).text("X");
        click++;
         $(".two").slideUp();
        $(".one").slideDown();
      flag = 1;
      }
    }
  })
  $(".restart").on("click",function(){
    flag = true;
    flag1=0;
    flag2=0;
      $(".one").slideDown();
      $(".two").slideUp();
    $("li").text("");
    $("li").css("opacity","1");
    $(".o").css("display","none");
    $(".draw").css("display","none");
    $(".x").css("display","none");
    $("li").css("background-color","#212121");
    $(".restart").css("display","none");
    $("li").css("pointer-events","");
  })
  var interval = setInterval(checkWin,500);
  function checkWin(){
    if((($("ul li:first-child").text()=="O")&&($("ul li:nth-child(2)").text()=="O")&&($("ul li:nth-child(3)").text()=="O"))||(($("ul li:first-child").text()=="O")&&($("ul li:nth-child(4)").text()=="O")&&($("ul li:nth-child(7)").text()=="O"))||(($("ul li:first-child").text()=="O")&&($("ul li:nth-child(5)").text()=="O")&&($("ul li:nth-child(9)").text()=="O"))||(($("ul li:nth-child(7)").text()=="O")&&($("ul li:nth-child(8)").text()=="O")&&($("ul li:nth-child(9)").text()=="O"))||(($("ul li:nth-child(4)").text()=="O")&&($("ul li:nth-child(5)").text()=="O")&&($("ul li:nth-child(6)").text()=="O"))||(($("ul li:nth-child(2)").text()=="O")&&($("ul li:nth-child(5)").text()=="O")&&($("ul li:nth-child(8)").text()=="O"))||(($("ul li:nth-child(3)").text()=="O")&&($("ul li:nth-child(6)").text()=="O")&&($("ul li:nth-child(9)").text()=="O"))||(($("ul li:nth-child(3)").text()=="O")&&($("ul li:nth-child(5)").text()=="O")&&($("ul li:nth-child(7)").text()=="O")))
      {
        $(".o").fadeIn();
        flag1++;
        if(flag1==1){
          score1++;
        }
        $(".first").text("Score(O): "+ score1);
        var value = "#E65100";
        if((($("ul li:first-child").text()=="O")&&($("ul li:nth-child(2)").text()=="O")&&($("ul li:nth-child(3)").text()=="O"))){
            $("ul li:first-child").css("background-color",value);
            $("ul li:nth-child(2)").css("background-color",value);
            $("ul li:nth-child(3)").css("background-color",value);
          }
         if((($("ul li:first-child").text()=="O")&&($("ul li:nth-child(4)").text()=="O")&&($("ul li:nth-child(7)").text()=="O"))){
            $("ul li:first-child").css("background-color",value);
            $("ul li:nth-child(4)").css("background-color",value);
            $("ul li:nth-child(7)").css("background-color",value);
          }
         if((($("ul li:first-child").text()=="O")&&($("ul li:nth-child(5)").text()=="O")&&($("ul li:nth-child(9)").text()=="O"))){
            $("ul li:first-child").css("background-color",value);
            $("ul li:nth-child(5)").css("background-color",value);
            $("ul li:nth-child(9)").css("background-color",value);
          }
         if((($("ul li:nth-child(7)").text()=="O")&&($("ul li:nth-child(8)").text()=="O")&&($("ul li:nth-child(9)").text()=="O"))){
            $("ul li:nth-child(7)").css("background-color",value);
            $("ul li:nth-child(8)").css("background-color",value);
            $("ul li:nth-child(9)").css("background-color",value);
          }
        if((($("ul li:nth-child(4)").text()=="O")&&($("ul li:nth-child(5)").text()=="O")&&($("ul li:nth-child(6)").text()=="O"))){
            $("ul li:nth-child(4)").css("background-color",value);
            $("ul li:nth-child(5)").css("background-color",value);
            $("ul li:nth-child(6)").css("background-color",value);
          }
        if((($("ul li:nth-child(2)").text()=="O")&&($("ul li:nth-child(5)").text()=="O")&&($("ul li:nth-child(8)").text()=="O"))){
            $("ul li:nth-child(2)").css("background-color",value);
            $("ul li:nth-child(5)").css("background-color",value);
            $("ul li:nth-child(8)").css("background-color",value);
          }
        if((($("ul li:nth-child(3)").text()=="O")&&($("ul li:nth-child(6)").text()=="O")&&($("ul li:nth-child(9)").text()=="O"))){
            $("ul li:nth-child(3)").css("background-color",value);
            $("ul li:nth-child(6)").css("background-color",value);
            $("ul li:nth-child(9)").css("background-color",value);
          }
        if((($("ul li:nth-child(3)").text()=="O")&&($("ul li:nth-child(5)").text()=="O")&&($("ul li:nth-child(7)").text()=="O"))){
            $("ul li:nth-child(3)").css("background-color",value);
            $("ul li:nth-child(5)").css("background-color",value);
            $("ul li:nth-child(7)").css("background-color",value);
          }
        $("li").css("opacity","0.4");
        $("li").css("pointer-events","none");
        $(".restart").fadeIn();
        click = 0;
      }
    if((($("ul li:first-child").text()=="X")&&($("ul li:nth-child(2)").text()=="X")&&($("ul li:nth-child(3)").text()=="X"))||(($("ul li:first-child").text()=="X")&&($("ul li:nth-child(4)").text()=="X")&&($("ul li:nth-child(7)").text()=="X"))||(($("ul li:first-child").text()=="X")&&($("ul li:nth-child(5)").text()=="X")&&($("ul li:nth-child(9)").text()=="X"))||(($("ul li:nth-child(7)").text()=="X")&&($("ul li:nth-child(8)").text()=="X")&&($("ul li:nth-child(9)").text()=="X"))||(($("ul li:nth-child(4)").text()=="X")&&($("ul li:nth-child(5)").text()=="X")&&($("ul li:nth-child(6)").text()=="X"))||(($("ul li:nth-child(2)").text()=="X")&&($("ul li:nth-child(5)").text()=="X")&&($("ul li:nth-child(8)").text()=="X"))||(($("ul li:nth-child(3)").text()=="X")&&($("ul li:nth-child(6)").text()=="X")&&($("ul li:nth-child(9)").text()=="X"))||(($("ul li:nth-child(3)").text()=="X")&&($("ul li:nth-child(5)").text()=="X")&&($("ul li:nth-child(7)").text()=="X")))
      {
        $(".x").fadeIn();
        flag2++;
        if(flag2==1){
          score2++;
        }
        $(".second").text("Score(X): "+ score2);
        var value = "#F50057";
        if((($("ul li:first-child").text()=="X")&&($("ul li:nth-child(2)").text()=="X")&&($("ul li:nth-child(3)").text()=="X"))){
            $("ul li:first-child").css("background-color",value);
            $("ul li:nth-child(2)").css("background-color",value);
            $("ul li:nth-child(3)").css("background-color",value);
          }
         if((($("ul li:first-child").text()=="X")&&($("ul li:nth-child(4)").text()=="X")&&($("ul li:nth-child(7)").text()=="X"))){
            $("ul li:first-child").css("background-color",value);
            $("ul li:nth-child(4)").css("background-color",value);
            $("ul li:nth-child(7)").css("background-color",value);
          }
         if((($("ul li:first-child").text()=="X")&&($("ul li:nth-child(5)").text()=="X")&&($("ul li:nth-child(9)").text()=="X"))){
            $("ul li:first-child").css("background-color",value);
            $("ul li:nth-child(5)").css("background-color",value);
            $("ul li:nth-child(9)").css("background-color",value);
          }
         if((($("ul li:nth-child(7)").text()=="X")&&($("ul li:nth-child(8)").text()=="X")&&($("ul li:nth-child(9)").text()=="X"))){
            $("ul li:nth-child(7)").css("background-color",value);
            $("ul li:nth-child(8)").css("background-color",value);
            $("ul li:nth-child(9)").css("background-color",value);
          }
        if((($("ul li:nth-child(4)").text()=="X")&&($("ul li:nth-child(5)").text()=="X")&&($("ul li:nth-child(6)").text()=="X"))){
            $("ul li:nth-child(4)").css("background-color",value);
            $("ul li:nth-child(5)").css("background-color",value);
            $("ul li:nth-child(6)").css("background-color",value);
          }
        if((($("ul li:nth-child(2)").text()=="X")&&($("ul li:nth-child(5)").text()=="X")&&($("ul li:nth-child(8)").text()=="X"))){
            $("ul li:nth-child(2)").css("background-color",value);
            $("ul li:nth-child(5)").css("background-color",value);
            $("ul li:nth-child(8)").css("background-color",value);
          }
        if((($("ul li:nth-child(3)").text()=="X")&&($("ul li:nth-child(6)").text()=="X")&&($("ul li:nth-child(9)").text()=="X"))){
            $("ul li:nth-child(3)").css("background-color",value);
            $("ul li:nth-child(6)").css("background-color",value);
            $("ul li:nth-child(9)").css("background-color",value);
          }
        if((($("ul li:nth-child(3)").text()=="X")&&($("ul li:nth-child(5)").text()=="X")&&($("ul li:nth-child(7)").text()=="X"))){
            $("ul li:nth-child(3)").css("background-color",value);
            $("ul li:nth-child(5)").css("background-color",value);
            $("ul li:nth-child(7)").css("background-color",value);
          }
        $("li").css("opacity","0.4");
        $("li").css("pointer-events","none");
        $(".restart").fadeIn();
        click = 0;
      }
    if(click>=9)
      {  
        $(".draw").fadeIn();
        $("li").css("opacity","0.4");
        $("li").css("pointer-events","none");
        $(".restart").fadeIn();
        click = 0;
      }
  }
})