$(document).ready(function() {

    var p1 = "X",// by default, player 1 is x, but this can be changed.
        p2 = "O",
        avatar = p1,
        move = 0,
        solved = false,
        numHumans = 2,
        recentMove = undefined;
    for (var i = 0; i <= 8; i++) $('.square').eq(i).html(i).css("color", "#262626");


    function switchModes() {
        $(this).addClass('alive');
        ($(this).attr('id') === "ai") ? ($('#human').removeClass('alive'), numHumans = 1) : ($('#ai').removeClass('alive'), numHumans = 2);
        reset();
        console.log(numHumans + " for " + $(this).attr('id'));
    }
    
    function reset() {
        $('.square').off('click');
        console.log('RESET');
        for (var i = 0; i <= 8; i++) $('.square').eq(i).html(i).css("color", "#262626");
        move = 0,
        solved = false,
        recentMove = undefined;
        $('.status').html('');
        $('.square').on('click', makeHumanMove);
        avatar = p1 === "X" ? p1 : p2;
        if (avatar === p2) { avatar = p1; nextMove(); }
    }
    
    function switchAvatars(){
        $(this).addClass('alive').css("color", "#d6c2d6");
        ($(this).attr('id') === "X") ? ($('#O').removeClass('alive').css("color","#6600cc"), p1 = "X", p2 = "O") : ($('#X').removeClass('alive').css("color","#6600cc"), p1 = "O", p2 = "X");
        console.log("p1: " +p1 + " vs p2:" + p2 + "   " + numHumans);
        reset();
    }

    function checkSolutions() {
        console.log("Making sure " + avatar + " didnt win during move #" + move);
        if (($('.square').eq(0).html() === $('.square').eq(1).html()) && ($('.square').eq(0).html() == $('.square').eq(2).html())) {
            solved = true;
        } else if (($('.square').eq(3).html() == $('.square').eq(4).html()) && ($('.square').eq(3).html() == $('.square').eq(5).html())) {
            solved = true;
        } else if (($('.square').eq(6).html() == $('.square').eq(7).html()) && ($('.square').eq(6).html() == $('.square').eq(8).html())) {
            solved = true;
        } else if (($('.square').eq(0).html() == $('.square').eq(3).html()) && ($('.square').eq(3).html() == $('.square').eq(6).html())) {
            solved = true;
        } else if (($('.square').eq(1).html() == $('.square').eq(4).html()) && ($('.square').eq(1).html() == $('.square').eq(7).html())) {
            solved = true;
        } else if (($('.square').eq(2).html() == $('.square').eq(5).html()) && ($('.square').eq(2).html() == $('.square').eq(8).html())) {
            solved = true;
        } else if (($('.square').eq(0).html() == $('.square').eq(4).html()) && ($('.square').eq(0).html() == $('.square').eq(8).html())) {
            solved = true;
        } else if (($('.square').eq(2).html() == $('.square').eq(4).html()) && ($('.square').eq(2).html() == $('.square').eq(6).html())) {
            solved = true;
        } else if (move == 9) {
            solved = "tie";
        }

        return solved; // returns 'false' if it hasnt been solved yet
    }

    function paintAIMove(id) {
        $('.square').eq(id).html(avatar).css("color", "#87b5c5");
    }

    function makeAIMove() {
        //var opp = (avatar == "X") ? "O" : "X";
        console.log(p2 + "'s turn...(the AI)");

        var a0 = $('.square').eq(0).html(),
            a1 = $('.square').eq(1).html(),
            a2 = $('.square').eq(2).html(),
            b0 = $('.square').eq(3).html(),
            b1 = $('.square').eq(4).html(),
            b2 = $('.square').eq(5).html(),
            c0 = $('.square').eq(6).html(),
            c1 = $('.square').eq(7).html(),
            c2 = $('.square').eq(8).html();

        function aiCompleteLine(player) {
            var success = undefined;
            console.log("Checking completion against " + player);
            // ... check horizontals for two of a kind (plus an empty square) to complete a line
            if (a0 == "0" && a1 == player && a2 == player) {
                paintAIMove(a0);
            } 
            else if (a0 == player && a1 == "1" && a2 == player) {
                paintAIMove(a1);} 
            else if (a0 == player && a1 == player && a2 == "2") {
                paintAIMove(a2);
            } else if (b0 == "3" && b1 == player && b2 == player) {
                paintAIMove(b0);
            } else if (b0 == player && b1 == "4" && b2 == player) {
                paintAIMove(b1);
            } // should have already tried this square earlier...
              else if (b0 == player && b1 == player && b2 == "5") {
                paintAIMove(b2);
            } else if (c0 == "6" && c1 == player && c2 == player) {
                paintAIMove(c0);
            } else if (c0 == player && c1 == "7" && c2 == player) {
                paintAIMove(c1);
            } else if (c0 == player && c1 == player && c2 == "8") {
                paintAIMove(c2);
            }

            // check verticals for two in a line of opponent (plus an empty quare)
            else if (a0 == "0" && b0 == player && c0 == player) {
                paintAIMove(a0);
            } else if (a0 == player && b0 == "3" && c0 == player) {
                paintAIMove(b0);
            } else if (a0 == player && b0 == player && c0 == "6") {
                paintAIMove(c0);
            } else if (a1 == "1" && b1 == player && c1 == player) {
                paintAIMove(a1);
            } else if (a1 == player && b1 == "4" && c1 == player) {
                paintAIMove(b1);
            } // should have already tried this square earlier...
            else if (a1 == player && b1 == player && c1 == "7") {
                paintAIMove(c1);
            } else if (a2 == "2" && b2 == player && c2 == player) {
                paintAIMove(a2);
            } else if (a2 == player && b2 == "5" && c2 == player) {
                paintAIMove(b2);
            } else if (a2 == player && b2 == player && c2 == "8") {
                paintAIMove(c2);
            }

            // check diagonals
            else if (a0 == "0" && b1 == player && c2 == player) {
                paintAIMove(a0);
            } else if (a0 == player && b1 == "4" && c2 == player) {
                paintAIMove(b1);
            } // should have already tried this square earlier...
            else if (a0 == player && b1 == player && c2 == "8") {
                paintAIMove(c2);
            } else if (a2 == "2" && b1 == player && c0 == player) {
                paintAIMove(a2);
            } else if (a2 == player && b1 == "4" && c0 == player) {
                paintAIMove(b1);
            } // should have already tried this square earlier...
            else if (a2 == player && b1 == player && c0 == "6") {
                paintAIMove(c0);
            } else {
                console.log("AI tried and failed to identify a line of " + player + "s.");
                success = false;
            }

            return success;
        }
        /*
   
     a0 | a1 | a2
     ____________
     b0 | b1 | b2
     ____________
     c0 | c1 | c2
   */
        console.log("the human recently moved to " + recentMove);
        // Priority -1:  Opening sequence - the AI prefers to start in the center, else picks a corner.
        if (move <= 2) {
            if (b1 == p1) {
                paintAIMove(a0);
            } // If user picked center, pick a corner
            else if (b1 == "4") {
                paintAIMove(b1);
            } else console.log("error1");
        } else if ((move <= 4) && (a0 == c2 || c0 == a2) && (a0 != p2 || c0 != p2)) { // user picked opposite corner on second human move, so we need to make the human block us by picking a side-middle piece
            if (a1 != "0") {
                paintAIMove(a1);
            } else if (b0 != "0") {
                paintAIMove(b0);
            } else if (c1 != "0") {
                paintAIMove(c1);
            } else if (b2 != "0") {
                paintAIMove(b2);
            } else console.log("error2");
        } else if ((move === 3) && (b1==p1) && ( b1 == c2 || b1 == c0 || b1 == a0 || b1 == a2)) {
            console.log("human picked center and a corner, so we need to block by picking a corner");
            if (a2 == "2") { paintAIMove(a2); }
            else if (c0 == "6") { paintAIMove(c0); }   
        } else {
            // Priority 1: Winning - if player = "avatar" is passed in, then we are trying to win.
            // aiCompleteLine(avatar) returns false if there was no winning line for avatar/ai
            var winTry = aiCompleteLine(p2);
            console.log("winTry is " + winTry);
            // Priority 2: Blocking - if player = "opp" is passed in, then we are trying to block. 
            // aiCompleteLine(opp) returns false if there was no winning line for opp/user that the AI needs to block
            if (winTry === false) {
                var blockTry = aiCompleteLine(p1);
                console.log("blockTry is " + blockTry);
                // If neither Priority was valid, then basically pick any square
                if (blockTry === false) {
                    if ((b1 == p2) && (recentMove == "7")) { // If AI has the center, try to pick a corner closest to user's recentMove
                        console.log("**DING DING to 7 " + c0);
                        if (c0 == "6") {
                            paintAIMove(c0);
                        } else if (a0 == "0") {
                            paintAIMove(a0);
                        } else if (c2 == "8") {
                            paintAIMove(c2);
                        } else if (a2 == "2") {
                            paintAIMove(a2);
                        } else console.log("error3");
                    } else { // By now just pick the first open position
                        console.log("ANYTHING RANDOM");
                        for (var i = 0; i <= 8; i++) {
                            if ($('.square').eq(i).html() != p2 && $('.square').eq(i).html() != p1) {
                                paintAIMove(i);
                                i = 9;
                            }
                        }
                    }
                } else console.log("error4");
            }
        }
        console.log("Now its " + p1 + "'s turn...");
          // return ability to click buttons after computer moves
        $('#reset').on('click', reset);
        $('.playerSelect').on('click', switchModes);
        $('.avatarSelect').on('click', switchAvatars);
        nextMove();
    }

    function makeHumanMove() {
        if (numHumans == 2) {
            if (($(this).html() != "X") && ($(this).html() != "O")) { // checks that no one has placed a peice there
                $(this).html(avatar).css("color", "#ada"); // prints the avatar (current user) in the square
                nextMove();
            }
        } else if (numHumans === 1 && avatar === p1) { // If playing against AI, only let the user click if its their turn
            if (($(this).html() != "X") && ($(this).html() != "O")) { // checks that no one has placed a peice there
                $(this).html(avatar).css("color", "#c2a3ba"); // prints the avatar (current user) in the square
                recentMove = $('.square').index(this);
                console.log("human just picked " + recentMove);
                nextMove();
            }
        } else if (numHumans === 1 && avatar === p2) {
            console.log("Its not your turn yet! Stop clicking! >:o " + avatar + "   " + p1);
        } else {
            console.log("error6 - something weird happened");
        }
    }

    function nextMove() {
        console.log("Checking previous move #" + move + " from " + avatar);
        if (!checkSolutions()) { // if the board hasn't been solved yet, change turns
            avatar = (avatar === p1) ? p2 : p1;
            move++;
            console.log("No solution found so switching players. Player for move #" + move + " is: " + avatar + " and p2 is " + p2);
            if (numHumans === 1) {
                if (avatar === p2) { // If its the computers turn to place a peice
                    console.log('AIs turn...');
                    $('#reset, .playerSelect, .avatarSelect').off('click');
                    setTimeout(makeAIMove, 800);
                }
            }
        } else {
            console.log("Solved? " + checkSolutions());
            (checkSolutions() === "tie") ? $('.status').html("Its a Tie."): $('.status').html(avatar + " Wins!");
            $('.square').off('click');
        }
    }
    

    $('.avatarSelect').on('click', switchAvatars);

    $('.playerSelect').on('click', switchModes);

    $('#reset').click(reset);
    
    $('.square').on('click', makeHumanMove);

});